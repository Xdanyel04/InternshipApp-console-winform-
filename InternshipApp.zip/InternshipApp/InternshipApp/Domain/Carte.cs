﻿namespace InternshipApp.Domain;

public class Carte
{
    private int id;
    private string titlu;
    private string autor;
    private int cantitate;
    private int cantitate_initiala;
    private int cantitate_imprumutata;
    private string gen;
    private double rating;
    private int nr_ratinguri;
    
    private static readonly Random random = new Random();

    public Carte(int id, string titlu, string autor, int cantitate, string gen)
    {
        this.id = id;
        this.titlu = titlu;
        this.autor = autor;
        this.cantitate = cantitate;
        this.cantitate_initiala = cantitate;
        this.cantitate_imprumutata = 0;
        this.gen = gen;
        this.rating = Math.Round(random.NextDouble()*4+1, 2);
        this.nr_ratinguri = 1;
    }


    public int Id
    {
        get => id;
        set => id = value;
    }

    public string Titlu
    {
        get => titlu;
        set => titlu = value ?? throw new ArgumentNullException(nameof(value));
    }

    public string Autor
    {
        get => autor;
        set => autor = value ?? throw new ArgumentNullException(nameof(value));
    }

    public int Cantitate
    {
        get => cantitate;
        set => cantitate = value >= 0 ? value : throw new ArgumentOutOfRangeException(nameof(value), "Nu poate fi un numar negativ de carti!");
    }

    public int CantitateInitiala
    {
        get => cantitate_initiala;
        set => cantitate_initiala = value;
    }

    public int CantitateImprumutata
    {
        get => cantitate_imprumutata;
        set => cantitate_imprumutata = value;
    }

    public string Gen
    {
        get => gen;
        set => gen = value ?? throw new ArgumentNullException(nameof(value), "Trebuie adaugat un gen pentru aceasta carte!");
    }

    public double Rating
    {
        get => rating;
        set => rating = (value >= 1 && value <= 5) ? value : throw new ArgumentOutOfRangeException(nameof(value), "Ratingul trebuie sa fie intre 1 si 5.");
    }

    public int NrRatinguri
    {
        get => nr_ratinguri;
        set => nr_ratinguri = value;
    }
}