﻿using InternshipApp.Domain;
using InternshipApp.Repository;
using InternshipApp.Service;
using InternshipApp.UI;

namespace InternshipApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Settings settings = Settings.GetInstance();
            string RepoType = settings.RepoType;

            Repo_Carte repo = null;
            if ("text".Equals(RepoType, StringComparison.OrdinalIgnoreCase))
                repo = new CarteTextFileRepo("C:\\Users\\ASUS\\RiderProjects\\InternshipApp\\InternshipApp\\carti.txt");
            else if ("json".Equals(RepoType, StringComparison.OrdinalIgnoreCase))
                repo = new RepoCarteJSON("C:\\Users\\ASUS\\RiderProjects\\InternshipApp\\InternshipApp\\carti.json");
            else if ("memory".Equals(RepoType, StringComparison.OrdinalIgnoreCase))
                repo = new Repo_Carte();
            else
            {
                Console.WriteLine("Tip de repo gresit");
                Environment.Exit(1);
            }

            Service.Service serv = new Service.Service(repo);
            UI.UI ui = new UI.UI(serv);
            ui.Start();

        }
    }
}