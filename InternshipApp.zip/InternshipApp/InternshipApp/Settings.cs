﻿namespace InternshipApp;

public class Settings
{
    private string repoType;
    private static Settings instance;
    
    private Settings() { }

    public string RepoType
    {
        get { return repoType; }
    }
    
    public static Settings GetInstance()
    {
        if (instance == null)
        {
            instance = new Settings();
            string settingsFilePath = "C:\\Users\\ASUS\\RiderProjects\\InternshipApp\\InternshipApp\\settings.txt"; 
            if (File.Exists(settingsFilePath))
            {
                foreach (var line in File.ReadAllLines(settingsFilePath))
                {
                    var tokens = line.Split('=');
                    if (tokens.Length == 2 && tokens[0].Trim() == "repoType")
                    {
                        instance.repoType = tokens[1].Trim();
                        break;
                    }
                }
            }
            else
            {
                throw new Exception("Fisierul de setari nu a fost gasit.");
            }
        }
        return instance;
    }
}
