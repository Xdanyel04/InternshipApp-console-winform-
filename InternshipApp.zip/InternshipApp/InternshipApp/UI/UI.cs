﻿using InternshipApp.Domain;

namespace InternshipApp.UI;

public class UI
{
    private Service.Service book;
    public UI(Service.Service book)
    { 
        this.book = book;
    }

    public void Start()
    {
        bool exit = false;
        while (!exit)
        {
            Console.WriteLine("0.Admin");
            Console.WriteLine("1.User");
            Console.WriteLine("2.Exit");
            try
            {
                int option = Convert.ToInt32(Console.ReadLine());
                switch (option)
                {
                    case 0:
                        Console.Clear();
                        bool adminExit = false;
                        while (!adminExit)
                        {
                            Console.WriteLine("0.Cautare carte");
                            Console.WriteLine("1.Adaugare carte");
                            Console.WriteLine("2.Stergere carte");
                            Console.WriteLine("3.Updatare carte");
                            Console.WriteLine("4.Afiseaza cartile");
                            Console.WriteLine("5.Exit la meniul anterior");
                            int option2 = Convert.ToInt32(Console.ReadLine());
                            switch (option2)
                            {
                                case 0:
                                    cautareCarte();
                                    break;
                                case 1:
                                    addCarte();
                                    break;
                                case 2:
                                    stergereCarte();
                                    break;
                                case 3:
                                    updateCarte();
                                    break;
                                case 4:
                                    showCarti();
                                    break;
                                case 5:
                                    adminExit = true;
                                    break;
                                default:
                                    Console.WriteLine("Optiune invalida!");
                                    break;
                            }
                        }
                        break;
                    case 1:
                        Console.Clear();
                        bool userExit = false;
                        while (!userExit)
                        {
                            Console.WriteLine("1.Imprumutare carte");
                            Console.WriteLine("2.Returnare carte");
                            Console.WriteLine("3.Exit");
                            int option3 = Convert.ToInt32(Console.ReadLine());
                            switch (option3)
                            {
                                case 1:
                                    imprumutareCarte();
                                    break;
                                case 2:
                                    returnareCarte();
                                    break;
                                case 3:
                                    userExit = true;
                                    break;
                                default:
                                    Console.WriteLine("Optiune invalida!");
                                    break;
                            }
                        }
                        break;
                    case 2:
                        Console.Clear();
                        exit = true;
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Optiune invalida!");
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("A aparut o eroare " + e.Message);
            }
            
        }
        
    }

    private void showCarti()
    {
        var carti = book.AfiseazaToateCartile();
        if (carti.Any())
        {
            foreach (var carte in carti)
            {
                Console.WriteLine("ID: " + carte.Id + ", Titlu: " + carte.Titlu + ", Autor: " + carte.Autor + 
                                  ", Cantitate: " + carte.Cantitate + ", Gen: " + carte.Gen + ", Rating: " + carte.Rating);

            }
        }
        else
            Console.WriteLine("Nu sunt carti disponibile");
    }
    
    private void addCarte()
    {
        Console.WriteLine("Introdu id-ul cartii");
        int id = Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine("Introdu titlul cartii");
        string titlu =  Console.ReadLine();
        
        Console.WriteLine("Introdu autorul cartii");
        string autor = Console.ReadLine();
        
        Console.WriteLine("Introdu cantitatea de carti");
        int cantitatea = Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine("Introdu genul cartii");
        string  gen = Console.ReadLine();
        
        Carte c1 =  new Carte(id, titlu, autor, cantitatea, gen);
        book.AdaugaCarte(c1);
    }

    private void stergereCarte()
    {
        showCarti();
        int nrCarti = book.AfiseazaToateCartile().Count;
        if (nrCarti > 0)
        {
            Console.WriteLine("Introdu id-ul cartii");
            int id = Convert.ToInt32(Console.ReadLine());
            book.stergereById(id);
        }
        
    }

    private void updateCarte()
    {
        Console.WriteLine("Introdu id-ul cartii pe care vrei sa o editezi");
        int id = Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine("Introdu noul titlul al cartii");
        string titlu = Console.ReadLine();
        
        Console.WriteLine("Introdu noul autor cartii");
        string autor = Console.ReadLine();
        
        Console.WriteLine("Introdu noua cantitate de cartii");
        int cantitatea = Convert.ToInt32(Console.ReadLine());
        
        Console.WriteLine("Introdu genul cartii");
        string  gen = Console.ReadLine();
        
        Carte c1 = new Carte(id, titlu, autor, cantitatea, gen);
        book.UpdateCarte(c1);
    }

    private void cautareCarte()
    {
        Console.WriteLine("Introdu filtrul dupa care vrei sa cauti (exemplu: Id, Titlu, Autor, Cantitate, Gen):");
        string filtru = Console.ReadLine();
        filtru = filtru.ToLower();
        if (filtru.Equals("id") || filtru.Equals("cantitate"))
        {
            Console.WriteLine("Introdu un numar pentru " + filtru + ":");
            string item = Console.ReadLine();
            if (int.TryParse(item, out int number))
            {
                var rezultate = book.CautareCarti(filtru, number.ToString());
                if (rezultate.Any())
                    foreach (var carte in rezultate)
                    {
                        Console.WriteLine("ID: " + carte.Id + ", Titlu: " + carte.Titlu + ", Autor: " + carte.Autor + 
                                          ", Cantitate: " + carte.Cantitate + ", Gen: " + carte.Gen + ", Rating: " + carte.Rating);

                    }
                else
                    Console.WriteLine("Nu s-au gasit carti cu acest criteriu");
            }

            else
                Console.WriteLine("Nu ai introdus un numar valid!");
        }
        else
        {
            Console.WriteLine("Introdu un cuvant pentru " + filtru + ":");
            string cuv = Console.ReadLine();
            var rezultate = book.CautareCarti(filtru, cuv);
            if(rezultate.Any())
                foreach (var carte in rezultate)
                {
                    Console.WriteLine("ID: " + carte.Id + ", Titlu: " + carte.Titlu + ", Autor: " + carte.Autor + 
                                      ", Cantitate: " + carte.Cantitate + ", Gen: " + carte.Gen + ", Rating: " + carte.Rating);
                }
            else
                Console.WriteLine("Nu s-au gasit carti cu acest criteriu");
        }
    }

    private void imprumutareCarte()
    {
        showCarti();
        Console.WriteLine("Introdu id cartii pe care vrei sa o imprumuti:");
        int id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("" +
                          "Introdu cate exemplare vrei sa imprumuti:" +
                          "");
        int cantitatea = Convert.ToInt32(Console.ReadLine());
        book.ImprumutCarti(id,cantitatea);
    }

    private void returnareCarte()
    {
        bool returnedAll = false;
        showCarti();
        Console.WriteLine("Introdu id cartii pe care vrei sa o returnezi:");
        int id = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Introdu cate exemplare vrei sa returnezi:");
        int cantitatea = Convert.ToInt32(Console.ReadLine());
        book.ReturnareCarti(id,cantitatea,ref returnedAll);
        if (returnedAll)
        {
            double rating;
            Console.WriteLine("Te rugam sa oferi un rating intre 1.0 si 5.0 pentru cartea citita:");
            while (!double.TryParse(Console.ReadLine(), out rating) || rating < 1.0 || rating > 5.0)
            {
                Console.WriteLine("Rating invalid. Introdu un număr între 1.0 si 5.0:");
            } 
            Carte c = book.FindCarteById(id);
            book.CalculareRating(c, rating);
            Console.WriteLine("Multumim ratingul a fost salvat!");
            book.UpdateCarte(c);
            
            Console.WriteLine("Doresti si o recomandare din partea noastra daca ti-a placut cartea citita? Da sau Nu");
            string alegere = Console.ReadLine();
            alegere = alegere.ToLower();
            if (alegere.Equals("da"))
            {
                PropunereCarti(c);
            }

        }
    }

    private void PropunereCarti(Carte c)
    {
        List<Carte>carteFctGen =  new List<Carte>();
        List<Carte> carteFctAutor = new List<Carte>();
        foreach (Carte carte in book.AfiseazaToateCartile())
        {
            if(carte.Gen == c.Gen && carte!=c)
                carteFctGen.Add(carte);
            if(carte.Autor == c.Autor && carte!=c)
                carteFctAutor.Add(carte);
        }

        if (carteFctGen.Any())
        {
            book.SortareCartiFiltrate(carteFctGen);
            Console.WriteLine("Aici ai o lista cu cele mai apreciate titluri de acelasi gen cu cartea tocmai citita");
            foreach (var carte in carteFctGen)
            {
                Console.WriteLine("ID: " + carte.Id + ", Titlu: " + carte.Titlu + ", Autor: " + carte.Autor + 
                                  ", Cantitate: " + carte.Cantitate + ", Gen: " + carte.Gen + ", Rating: " + carte.Rating);

            }
        }
        if (carteFctAutor.Any())
        {
            book.SortareCartiFiltrate(carteFctAutor);
            Console.WriteLine("Aici ai o lista cu cele mai apreciate titluri de acelasi autor cu cartea tocmai citita");
            foreach (var carte in carteFctAutor)
            {
                Console.WriteLine("ID: " + carte.Id + ", Titlu: " + carte.Titlu + ", Autor: " + carte.Autor + 
                                  ", Cantitate: " + carte.Cantitate + ", Gen: " + carte.Gen + ", Rating: " + carte.Rating);

            }
        }

        if (!carteFctGen.Any() && !carteFctAutor.Any())
        {
            Console.WriteLine("Nu mai avem alte titluri asemanatoare cu ceea ce ai citit dar iti recomandam cartea cea mai apreciata de pe site-ul nostru!");
            Carte carteBuna = book.CarteApreciata();
            Console.WriteLine("ID: " + carteBuna.Id + ", Titlu: " + carteBuna.Titlu + ", Autor: " + carteBuna.Autor + 
                                                ", Cantitate: " + carteBuna.Cantitate + ", Gen: " + carteBuna.Gen + ", Rating: " + carteBuna.Rating);
        }
    }
}