﻿using InternshipApp.Domain;
using InternshipApp.Repository;

namespace InternshipApp.Service;

public class Service
{
    private Repo_Carte CarteRepo = new Repo_Carte();

    public Service(Repo_Carte CarteRepo)
    {
        this.CarteRepo = CarteRepo;
    }

    public void AdaugaCarte(Carte c)
    {
        CarteRepo.Adaugare(c);
    }

    public Carte FindCarteById(int id)
    {
        return CarteRepo.FindCarteById(id);
    }

    public void stergereById(int id)
    {
        Carte c = CarteRepo.FindCarteById(id);
        if (c != null)
            StergereCarte(c);
        else
            throw new Exception("Cartea cu id-ul specificat nu exista");
    }

    public void StergereCarte(Carte c)
    {
        CarteRepo.Stergere(c);
    }

    public void UpdateCarte(Carte c)
    {
        CarteRepo.Update(c);
    }

    public List<Carte> AfiseazaToateCartile()
    {
        return CarteRepo.GetAll();
    }
    
    public List<Carte> CautareCarti(string filter, string item)
    {
        List<Carte> rezultate = new List<Carte>();
        foreach (Carte c1 in CarteRepo.GetAll())
        {
            switch (filter.ToLower())
            {
                case "id":
                    if (c1.Id == Int32.Parse(item))
                        rezultate.Add(c1); 
                    break;
                case "titlu":
                    if(c1.Titlu == item)
                        rezultate.Add(c1);
                    break;
                case "autor":
                    if (c1.Autor == item)
                        rezultate.Add(c1);
                    break;
                case "cantitate":
                    if(c1.Cantitate == Int32.Parse(item))
                        rezultate.Add(c1);
                    break;
                case "gen":
                    if (c1.Gen == item)
                        rezultate.Add(c1);
                    break;
                default:
                    throw new Exception("Filtru invalid!");
            }
        }
        return rezultate;
    }

    public void ImprumutCarti(int id, int cantitate)
    {
        foreach (Carte c1 in CarteRepo.GetAll())
        {
            if (c1.Id == id)
            {
                if (c1.Cantitate < cantitate)
                    throw new Exception("Nu exista suficient stoc pentru a imprumuta: " + cantitate + " carti");
                
                c1.Cantitate -= cantitate;
                c1.CantitateImprumutata+=cantitate;
                return;
            }
        }

        throw new Exception("Cartea cu id-ul specificat nu a fost gasita");
    }

    public void ReturnareCarti(int id, int cantitate, ref bool returnedAll)
    {
        bool found = false;
        foreach (Carte c1 in CarteRepo.GetAll())
        {
            if (c1.Id == id)
            {
                found = true;
                if (cantitate > c1.CantitateImprumutata)
                    throw new Exception("S-au returnat mai multe carti decat s-au imprumutat");
                
                if (c1.Cantitate + cantitate > c1.CantitateInitiala)
                    throw new Exception("S-au returnat prea multe cărți și se depășește numărul inițial.");
                
                c1.Cantitate += cantitate;
                c1.CantitateImprumutata -= cantitate;
                if (c1.CantitateImprumutata == 0)
                {
                     Console.WriteLine("Ai returnat toate cartile imprumutate de acest tip!");
                     returnedAll = true;
                     
                }
                   
                else
                    Console.WriteLine("Mai ai de returnat: " + c1.CantitateImprumutata + " carti din acest tip!");
            }
        }
        if (!found)
            Console.WriteLine("Cartea cu id-ul specificat nu a fost gasita!");
    }

    public void CalculareRating(Carte c,double rating)
    {
        c.Rating = (c.Rating * c.NrRatinguri + rating) / (c.NrRatinguri + 1);
        c.NrRatinguri++;
    }

    public Carte CarteApreciata()
    {
        List<Carte> carti = CarteRepo.GetAll();
        carti.Sort((x, y) => y.Rating.CompareTo(x.Rating));
        if(carti.Any())
            return carti[0];
        else
            throw new Exception("Nu exista carti disponibile");
    }

    public void SortareCartiFiltrate(List<Carte> carti)
    {
        carti.Sort((x, y) => y.Rating.CompareTo(x.Rating));
    }
    
    
}