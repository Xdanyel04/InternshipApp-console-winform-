﻿using InternshipApp.Domain;

namespace InternshipApp.Repository;

public class CarteTextFileRepo : Repo_Carte
{
    private readonly string filePath;

    public CarteTextFileRepo(String filePath)
    {
        this.filePath = filePath;
        try
        {
            loadFromFile();
        }
        catch (Exception e)
        {
            throw new Exception("Eroare la incarcarea fisierului: " + filePath, e);
        }
    }

    private void loadFromFile()
    {
        if (!File.Exists(filePath))
            return;
        
        foreach (var line in  File.ReadAllLines(filePath))
        {
            var tokens = line.Split(',');
            if (tokens.Length != 5)
            {
                throw new Exception("Linie invalida in fisier" + line);
            }
            else
            {
                var id = int.Parse(tokens[0]);
                var titlu = tokens[1];
                var autor = tokens[2];
                var cantitate = int.Parse(tokens[3]);
                var gen = tokens[4];
                Carte c1 =  new Carte(id, titlu, autor, cantitate,gen);
                base.Adaugare(c1);
            }
        }
    }

    private void saveToFile()
    {
        using (var writer = new StreamWriter(filePath, append: false))
        {
            foreach (var carte in GetAll())
            {
                var line = carte.Id + "," + carte.Titlu + "," + carte.Autor + "," + carte.Cantitate + "," + carte.Gen + "," + carte.Rating;
                writer.WriteLine(line);
            }
        }
        
    }

    public override void Adaugare(Carte carte)
    {
        base.Adaugare(carte);
        saveToFile();
    }

    public override void Stergere(Carte carte)
    {
        base.Stergere(carte);
        saveToFile();
    }

    public override void Update(Carte carte)
    {
        base.Update(carte);
        saveToFile();
    }
    
}