﻿using System.Text.Json;
using InternshipApp.Domain;

namespace InternshipApp.Repository;

public class RepoCarteJSON : Repo_Carte
{
    private readonly string filePath;

    public RepoCarteJSON(string repoFilePath)
    {
        this.filePath = repoFilePath;
        try
        {
            loadFromFile();
        }
        catch (Exception ex)
        {
            throw new  Exception("Error loading file: " + ex.Message);
        }
    }

    private void loadFromFile()
    {
        if(!File.Exists(filePath))
            return;
        
        string json = File.ReadAllText(filePath);
        List<Carte>? carti = JsonSerializer.Deserialize<List<Carte>>(json);
        if (carti != null)
        {
            foreach (Carte cart in carti)
            {
                base.Adaugare(cart);
            }
        }
    }

    private void SaveToFile()
    {
        var carti = GetAll();
        var json  = JsonSerializer.Serialize(carti, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(filePath, json);
    }

    public override void Adaugare(Carte carte)
    {
        base.Adaugare(carte);
        SaveToFile();
    }

    public override void Stergere(Carte carte)
    {
        base.Stergere(carte);
        SaveToFile();
    }

    public override void Update(Carte carte)
    {
        base.Update(carte);
        SaveToFile();
    }
    
}