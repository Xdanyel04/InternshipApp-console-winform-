﻿using InternshipApp.Domain;

namespace InternshipApp.Repository;

public class Repo_Carte : Repository<Carte>
{
    public override bool ExistById(int id)
    {
        foreach (Carte c in carti)
        {
            if(c.Id == id)
                return true;
        }
        return false;
    }
    
    public override void Adaugare(Carte carte)
    {
        if(carte ==  null)
            throw new ArgumentNullException(nameof(carte));
        if(string.IsNullOrWhiteSpace(carte.Titlu))
            throw new ArgumentException("Trebuie sa existe un titlu");
        if(string.IsNullOrWhiteSpace(carte.Autor))
            throw new ArgumentException("Trebuie sa existe un autor");
        if (carte.Cantitate<0)
            throw new ArgumentException("Trebuie sa se adauge cel putin o carte!");
        if(string.IsNullOrWhiteSpace(carte.Gen))
            throw new ArgumentException("Trebuie sa existe un gen pentru carte");
        if(ExistById(carte.Id))
                throw new ArgumentException("Id-ul mai apare in lista. Este necesar un id diferit");
        carti.Add(carte);
    }
    

    public override void Stergere(Carte carte)
    {
        if(carte ==  null)
            throw new ArgumentNullException(nameof(carte));
        if(!ExistById(carte.Id))
            throw new ArgumentException("Nu s-a gasit cartea cu id-ul precizat");
        carti.Remove(carte);
    }

    public override Carte FindCarteById(int id)
    {
        foreach (Carte c in carti)
        {
            if(c.Id == id)
                return c;
        }
        return null;
    }

    public override void Update(Carte carte)
    {
        if(carte ==  null)
            throw new ArgumentNullException(nameof(carte));
        if(string.IsNullOrWhiteSpace(carte.Titlu))
            throw new ArgumentException("Trebuie sa existe un titlu");
        if(string.IsNullOrWhiteSpace(carte.Autor))
            throw new ArgumentException("Trebuie sa existe un autor");
        if (carte.Cantitate<0)
            throw new ArgumentException("Trebuie sa se adauge cel putin o carte!");
        if(string.IsNullOrWhiteSpace(carte.Gen))
            throw new ArgumentException("Trebuie sa existe un gen pentru carte");
        Carte carteExistenta =  FindCarteById(carte.Id);
        if (carteExistenta != null)
        {
            carti.Remove(carteExistenta);
            carti.Add(carte);
        }
        else
        {
            throw new Exception("Cartea nu exista");
        }
    }
}