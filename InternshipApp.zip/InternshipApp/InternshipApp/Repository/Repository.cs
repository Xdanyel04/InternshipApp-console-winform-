﻿using InternshipApp.Domain;

namespace InternshipApp.Repository;

public abstract class Repository<T>
{
    protected List<T> carti =  new List<T>();
    
    public abstract void Adaugare(T entity);
    public abstract void Stergere(T entity);
    public abstract bool ExistById(int id);

    public List<T> GetAll()
    {
        return carti;
    }
    
    public abstract T FindCarteById(int id);
    public abstract void Update(T entity);
}